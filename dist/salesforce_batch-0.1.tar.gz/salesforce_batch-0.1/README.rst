********************
Simple SF Batch
********************

This is a fork of simple salesforce to which I added one multi-batched bulk upload jobs. 

